package tp05

sealed trait Term
case object EOF extends Term
