package tp05

object Util {
  /** t est-il une valeur ? */
  def isVal(t : Term) : Boolean = ???

  /** t est-il une valeur numérique ? */
  def isNumVal(t : Term) : Boolean = ???
}