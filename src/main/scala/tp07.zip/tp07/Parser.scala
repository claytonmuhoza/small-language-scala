package tp07

import scala.util.parsing.combinator.JavaTokenParsers

/**
 * prog --> '\z'
 *   |  cmd ";;"
 * cmd --> t
 *   |  val v '=' t
 * t --> open
 *   |  atom+ t?
 * open --> lambda x':' typ'.' t
 *   |  if t then t else t
 *   |  succ t
 *   |  pred t
 *   |  iszero t
 * atom --> x
 *   |  '('t')'
 *   |  true
 *   |  false
 *   |  0
 * typ --> atomTyp ("->" atomTyp)*
 * atomTyp --> '('typ')'
 *   | Bool
 *   | Nat
 * Indication : le non-terminal "typ" engendre un atomTyp suivi d'une séquence
 *  éventuellement vide de ('->' atomTyp). On gère cette situation de manière
 *  similaire à la séquence d'applications traitée la séance précédente. Cette
 *  fois, on fera appel à la méthode "Util.buildFctType" pour construire le
 *  type fonctionnel en cascade à partir d'une liste de types. 
 */
class Parser extends JavaTokenParsers {
  protected override val whiteSpace = """(\s|#.*)+""".r
  override val ident = """[a-zA-Z][a-zA-Z0-9]*""".r
  def keywords = Set("val")
  
  def prog : Parser[Term] = eof | cmd<~";;"
  def cmd : Parser[Term] = term
      | ("val"~>variable)~("="~>term) ^^ { case x~t => Val(x, t) }
  def eof = """\z""".r ^^ { _ => EOF}
  def term : Parser[Term] = ???
  def open = ???
  def lambda = ???
  def cond = ???
  def succ = ???
  def pred = ???
  def isZero = ???
  def atom = ???
  def variable = ???
  def tFalse = ???
  def tTrue = ???
  def zero = ???
  def typ : Parser[Typ] = ???
  def atomTyp = ???
  def bool = ???
  def nat = ???
}
