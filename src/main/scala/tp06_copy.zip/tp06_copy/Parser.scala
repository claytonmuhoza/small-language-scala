package tp06

import scala.util.parsing.combinator.JavaTokenParsers
import Util._

/**
 * prog --> '\z'
 *   | cmd ";;"
 * cmd --> term
 *   |  val v '=' term
 * term --> lambda x'.' term
 *   |  atom+ term?
 * atom --> x
 *   | '(' term ')'
 *   
 * La production "atom+" produit une liste de termes. On les transforme
 * en une séquence d'applications avec "Util.buildApp".
 *
 * Les variables respectent le motif [a-zA-Z][a-zA-Z0-9]* et ne
 * doivent pas être des mots-clés du langage.
 */
class Parser extends JavaTokenParsers {
  protected override val whiteSpace = """(\s|#.*)+""".r
  override val ident: Parser[String] = """[a-zA-Z][a-zA-Z0-9]*""".r
  val keywords: Set[String] = Set("val", "lambda")

  // Programme principal
  def prog: Parser[Term] = eof | cmd <~ ";;"

  // Commande
  def cmd: Parser[Term] = 
    term | ("val" ~> variable) ~ ("=" ~> term) ^^ { case x ~ t => Val(x, t) }

  // Fin du fichier
  def eof: Parser[Term] = """\z""".r ^^ { _ => EOF }

  // Terme : séquence d'atomes (termes) avec une application possible
  def term: Parser[Term] = 
    lambda | (rep1(atom) ~ opt(term)) ^^ { case atoms ~ t => buildApp(atoms ++ t.toList) }

  // Lambda
  def lambda: Parser[Term] = 
    "lambda" ~> variable ~ ("." ~> term) ^^ { case x ~ t => Abs(x, t) }

  // Atome : une variable ou un terme entre parenthèses
  def atom: Parser[Term] = 
    variable | "(" ~> term <~ ")"

  // Variable : identifiant qui n'est pas un mot-clé
  def variable: Parser[Var] = 
    ident.filter(!keywords.contains(_)) ^^ { Var(_) }
}