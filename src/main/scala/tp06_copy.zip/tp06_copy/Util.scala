package tp06

object Util {
  /**
   * Construit une séquence d'applications de la forme t1 t2 ... tk
   *  à partir de terms = List(t1, t2, ..., tk).
   * Rappel : l'application est associative à gauche
   *  (i.e. t1 t2 t3 ~ (t1 t2) t3)
   */
  def buildApp(terms : List[Term]) : Term = terms match {
    case Nil => throw new IllegalArgumentException("Empty list")
      case t :: Nil => t  
      case t :: ts => App(t, buildApp(ts)) 
  }

  /**  Remplace, dans t2, toutes les occurrences de x par t1. */
  def subst(x : Var, t1 : Term, t2 : Term) : Term = t2 match {
    case v: Var if v == x => t1
    case Val(x, t) => Val(x, subst(x, t1, t))
    case App(t,t_) => App(subst(x, t1, t), subst(x, t1, t_))
    case Abs(v, t) if v != x => Abs(v, subst(x, t1, t)) 
    case _ => t2
  } 
  
  type Context = List[Val]
  
  /** 
   * Remplace, dans t, chaque alias du contexte ctx par le terme qui lui est
   *  associé.
   */
  def inject(ctx : Context, t : Term) : Term = ctx match {
    case List() => t
    case x::y => inject(y, subst(x.x, x.t, t))
  }
  
  /** Si optT définit un nouvel alias, l'ajouter en tête du contexte ctx. */
  def buildNewCtx(ctx : Context, optT : Option[Term]) : Context = optT match {
    case Some(Val(x, t)) => Val(x, t) :: ctx
    case _ => ctx
  }
  
  /** t est-il une valeur ? */
    def isVal(t : Term) : Boolean = t match
    case Val(_,_) | Abs(_,_)=> true
    case _ => false
  
  /** t est-il un terme clos ? */
  def isClosed(t : Term) : Boolean = {
    def checkClosed(t: Term, ctx: List[String]) : Boolean = t match {
      case Var(v) => ctx.contains(v)
      case Val(x, t) => checkClosed(t, ctx)
      case Abs(x, t) => checkClosed(t, x.name ::ctx)
      case App(t1, t2) => checkClosed(t1, ctx) && checkClosed(t2, ctx)
      case _ => true
    }
    checkClosed(t, List())
  }
  
}