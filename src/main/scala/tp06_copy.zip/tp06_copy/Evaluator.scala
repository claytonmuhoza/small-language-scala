package tp06

import Util._

class Evaluator {
  /** Réalise un pas d'évaluation, i.e. produit t' tel que t --> t'. */
  private def eval(t : Term) : Term  = t match {
    case t if isVal(t) => t
    case App(Abs(x, t1), t2) if isVal(t2) => subst(x, t2, t1)
    case App(t1, t2) if isVal(t1) => App(t1, eval(t2))
    case App(t1, t2) => App(eval(t1), t2)
    case Val(r, App(t1,t2)) => Val(r, t1)
    case _ => throw new Exception("Evaluation impossible")
  }
  /** Evalue t jusqu'à obtenir un terme bloqué. */
  def evaluate(t : Term) : Term = {
    if (isVal(t)) t else evaluate(eval(t))
  }
}
