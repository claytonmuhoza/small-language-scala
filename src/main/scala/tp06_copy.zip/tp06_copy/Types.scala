package tp06

// Définition des termes du lambda-calcul
sealed trait Term // Trait scellé pour représenter un terme abstrait du langage

// Fin de fichier (EOF), utilisé pour signaler la fin du parsing
case object EOF extends Term

// Variable (ex : x, y, ...)
case class Var(name: String) extends Term

// Déclaration d'une valeur nommée : val x = t
case class Val(x: Var, t: Term) extends Term

// Abstraction lambda : λx. t (fonction anonyme)
case class Abs(param: Var, body: Term) extends Term

// Application de fonction : (t1 t2) -> application d'un terme à un autre
case class App(func: Term, arg: Term) extends Term